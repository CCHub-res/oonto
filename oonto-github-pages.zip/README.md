# Oonto Banking Dummy

Statischer GitHub-Pages-Dummy mit Supabase-Anbindung.

## Deployment

1. Repository auf GitHub erstellen.
2. `index.html` in den Root des Repositories hochladen.
3. GitHub → Settings → Pages.
4. Source: `Deploy from a branch`.
5. Branch: `main`, Folder: `/root`.
6. Speichern.

## Supabase Hinweise

- In Supabase Auth → Providers → Email für den Dummy am besten Email confirmations deaktivieren.
- Unter Supabase Auth → URL Configuration nach dem Deployment die GitHub-Pages-URL als Site URL setzen.
- Kein service_role Key im Frontend verwenden.
